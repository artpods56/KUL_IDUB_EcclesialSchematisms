from uuid import UUID


class GrafyCoreError(Exception):
    """Base application error."""


class NotFoundError(GrafyCoreError):
    """A requested resource was not found."""

    def __init__(self, resource: str, resource_id: str) -> None:
        self.resource = resource
        self.resource_id = resource_id
        super().__init__(f"{resource} not found: {resource_id}")


class ObjectAlreadyExistsError(GrafyCoreError):
    """Raised when an object already exists in the storage backend."""


class ConcurrentWriteError(GrafyCoreError):
    """Raised when persistence detects an optimistic concurrency conflict."""


class IdentityInvariantError(GrafyCoreError):
    """Raised when an identity or workspace invariant would be violated."""


class BootstrapOwnerRequiredError(IdentityInvariantError):
    """Raised while the sealed legacy workspace is awaiting its owner."""


class BootstrapOwnerMismatchError(IdentityInvariantError):
    """Raised when a login does not match the configured bootstrap identity."""


class LastWorkspaceOwnerError(IdentityInvariantError):
    """Raised when an operation would remove the last active workspace owner."""


class UserDisabledError(IdentityInvariantError):
    """Raised when a disabled user attempts to authenticate or authorize."""


class CapabilityDeniedError(IdentityInvariantError):
    """Raised when an active membership lacks one required capability."""

    def __init__(self, *, capability: str, workspace_id: UUID, user_id: UUID) -> None:
        self.capability = capability
        self.workspace_id = workspace_id
        self.user_id = user_id
        super().__init__(
            f"User {user_id} is not authorized for capability {capability!r} "
            f"in workspace {workspace_id}"
        )


class SavedGraphRevisionConflictError(GrafyCoreError):
    def __init__(
        self,
        *,
        graph_id: UUID,
        expected_revision: int,
        actual_revision: int | None,
    ) -> None:
        self.graph_id = graph_id
        self.expected_revision = expected_revision
        self.actual_revision = actual_revision
        if actual_revision is None:
            detail = "the graph changed while it was being saved"
        else:
            detail = f"the current revision is {actual_revision}"
        super().__init__(
            f"Saved graph {graph_id} revision conflict: expected "
            f"{expected_revision}, but {detail}"
        )


class GraphFolderNameConflictError(GrafyCoreError):
    """Raised when one workspace already has a folder with the requested name."""

    def __init__(self, *, workspace_id: UUID, name: str) -> None:
        self.workspace_id = workspace_id
        self.name = name
        super().__init__(
            f"Graph folder name {name!r} is already in use in workspace {workspace_id}"
        )


class CollaborationError(GrafyCoreError):
    """Base error for collaborative head and command workflows."""

    error_code: str = "collaboration_error"


class MissingCollaborativeHeadError(CollaborationError):
    error_code = "missing_collaborative_head"

    def __init__(self, *, workspace_id: UUID, graph_id: UUID) -> None:
        self.workspace_id = workspace_id
        self.graph_id = graph_id
        super().__init__(
            f"Collaborative head missing for graph {graph_id} in workspace "
            f"{workspace_id}"
        )


class CollaborationHeadConflictError(CollaborationError):
    error_code = "head_moved"

    def __init__(
        self,
        *,
        workspace_id: UUID,
        graph_id: UUID,
        expected_sequence: int,
        actual_sequence: int,
        room_epoch: UUID,
    ) -> None:
        self.workspace_id = workspace_id
        self.graph_id = graph_id
        self.expected_sequence = expected_sequence
        self.actual_sequence = actual_sequence
        self.room_epoch = room_epoch
        super().__init__(
            f"Collaborative head for graph {graph_id} moved: expected sequence "
            f"{expected_sequence}, actual {actual_sequence}"
        )


class CollaborationIdempotencyMismatchError(CollaborationError):
    error_code = "idempotency_mismatch"

    def __init__(self, *, workspace_id: UUID, graph_id: UUID, command_id: UUID) -> None:
        self.workspace_id = workspace_id
        self.graph_id = graph_id
        self.command_id = command_id
        super().__init__(
            f"Command id {command_id} was reused with a different payload for "
            f"graph {graph_id} in workspace {workspace_id}"
        )


class CollaborationCommandRejectedError(CollaborationError):
    error_code = "command_rejected"

    def __init__(self, *, code: str, message: str) -> None:
        self.error_code = code
        super().__init__(message)


class CollaborationUncheckpointedError(CollaborationError):
    error_code = "uncheckpointed_head"

    def __init__(
        self,
        *,
        workspace_id: UUID,
        graph_id: UUID,
        head_sequence: int,
        checkpoint_sequence: int,
    ) -> None:
        self.workspace_id = workspace_id
        self.graph_id = graph_id
        self.head_sequence = head_sequence
        self.checkpoint_sequence = checkpoint_sequence
        super().__init__(
            f"Collaborative head for graph {graph_id} has uncheckpointed "
            f"commands at sequence {head_sequence} "
            f"(checkpointed through {checkpoint_sequence})"
        )


class CollaborationActiveExecutionError(CollaborationError):
    error_code = "active_execution"

    def __init__(
        self,
        *,
        workspace_id: UUID,
        graph_id: UUID,
        execution_id: UUID,
    ) -> None:
        self.workspace_id = workspace_id
        self.graph_id = graph_id
        self.execution_id = execution_id
        super().__init__(
            f"Graph {graph_id} in workspace {workspace_id} has active execution "
            f"{execution_id}"
        )
